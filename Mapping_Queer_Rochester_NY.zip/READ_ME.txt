READ ME 

Mapping Queer Rochester By Rebecca Wright, Claire Becker and Anna Grace Wenger.

http://rwrig17.digitalscholar.rochester.edu/PuttingRochestersLGBTQHistoryontheMap/about/

